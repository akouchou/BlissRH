importScripts('https://storage.googleapis.com/workbox-cdn/releases/3.6.1/workbox-sw.js');

// workbox.setConfig({debug: true});
// workbox.core.setLogLevel(workbox.core.LOG_LEVELS.debug);

// Cache the Google Fonts stylesheets with a stale-while-revalidate strategy.
workbox.routing.registerRoute(
    /^https:\/\/fonts\.googleapis\.com/,
    workbox.strategies.staleWhileRevalidate({
        cacheName: 'google-fonts-stylesheets',
    })
);

// Cache the underlying font files with a cache-first strategy for 1 year.
workbox.routing.registerRoute(
    /^https:\/\/fonts\.gstatic\.com/,
    workbox.strategies.cacheFirst({
        cacheName: 'google-fonts-webfonts',
        plugins: [
            new workbox.cacheableResponse.Plugin({
                statuses: [0, 200],
            }),
            new workbox.expiration.Plugin({
                maxAgeSeconds: 60 * 60 * 24 * 365,
                maxEntries: 30,
            }),
        ],
    })
);

workbox.routing.registerRoute(
    /\.(?:js|css)$/,
    workbox.strategies.staleWhileRevalidate({
        cacheName: 'static-resources',
    })
);

workbox.routing.registerRoute(
    /\.(?:png|gif|jpg|jpeg|svg)$/,
    workbox.strategies.cacheFirst({
        cacheName: 'images',
        plugins: [
            new workbox.expiration.Plugin({
                maxEntries: 60,
                maxAgeSeconds: 30 * 24 * 60 * 60, // 30 Days
            }),
        ],
    })
);

workbox.googleAnalytics.initialize();


/*
| --------------------------------------------------------------------------
|  Fetch return a promise : so we can catch if something goes wrong
| --------------------------------------------------------------------------
|
|  In this example : if the request can't be made we reply with a text response
|
*/

var responseContent =
    `
<!DOCTYPE html>
<html class="no-js">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
    <body>
        <style>
          
          body{
            background-color: #fff;
            font-family : sans-serif;
            text-align: center;
            color: #000;
          }
          
           img{
               display:block;
               margin:auto;
           }
          
          a{
            display:block;
            margin:auto;
            width: 200px;
            max-width: 100%;
            background-color: #d20000;
            height : 40px; 
            line-height: 40px;
            color: #fff;
            text-decoration:none;            
            margin-top: 30px; 
          }
          
        </style>        
        <h1>Vous semblez ne plus avoir de connexion pour consulter cegos.fr</h1>
       
        <p>Une question ? Appelez-nous au 01 55 00 95 95</p>
      
    </body>
</html>
`;


self.addEventListener("fetch", function (event) {
    event.respondWith(
        fetch(event.request).catch(function () {
            return new Response(responseContent, {headers: {"Content-Type": "text/html; charset=utf-8"}}
            );
        })
    );
});